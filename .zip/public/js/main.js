// ES6 or Vanilla JavaScript
"use strict";